// ================================================
// VV — View-Once Unlock
// Developed by Mehdi © 2026
// ================================================

function box(lines) {
    const w = 24;
    const top = '╭' + '─'.repeat(w) + '╮';
    const bot = '╰' + '─'.repeat(w) + '╯';
    const body = lines.map(l => `│ ${l}`).join('\n');
    return `${top}\n${body}\n${bot}\n\n> _𝑴𝒆𝒉𝒅𝒊 ✓_`;
}

function usage(prefix) {
    return box([
        '⚠️ 𝑼𝒔𝒂𝒈𝒆',
        '',
        `➫ Reply to a view-once`,
        `  photo, video or voice`,
        `  note with ${prefix}vv`
    ]);
}

function notViewOnce() {
    return box([
        '❌ 𝑵𝒐𝒕 𝑽𝒊𝒆𝒘-𝑶𝒏𝒄𝒆',
        '',
        '➫ That message isn\'t a',
        '  view-once photo/video/',
        '  voice note.'
    ]);
}

function failed(reason) {
    return box([
        '❌ 𝑼𝒏𝒍𝒐𝒄𝒌 𝑭𝒂𝒊𝒍𝒆𝒅',
        '',
        `➫ ${reason}`
    ]);
}

// ============================================================
// 🔍 CORE: Find the real view-once media inside any wrapper
// Handles: viewOnceMessage, viewOnceMessageV2,
//          viewOnceMessageV2Extension, plain media w/ viewOnce
// ============================================================
function extractViewOnceMedia(msg) {
    if (!msg) return null;

    // Unwrap nested wrappers first
    let m = msg;
    let guard = 0;
    while (guard++ < 5) {
        if (m.viewOnceMessage?.message) { m = m.viewOnceMessage.message; continue; }
        if (m.viewOnceMessageV2?.message) { m = m.viewOnceMessageV2.message; continue; }
        if (m.viewOnceMessageV2Extension?.message) { m = m.viewOnceMessageV2Extension.message; continue; }
        break;
    }

    // Now check for media with viewOnce flag
    if (m.imageMessage && m.imageMessage.viewOnce) {
        return { type: 'imageMessage', inner: m.imageMessage };
    }
    if (m.videoMessage && m.videoMessage.viewOnce) {
        return { type: 'videoMessage', inner: m.videoMessage };
    }
    if (m.audioMessage && m.audioMessage.viewOnce) {
        return { type: 'audioMessage', inner: m.audioMessage };
    }

    // Also accept media even without viewOnce flag IF it came from
    // a view-once wrapper (some WA versions strip the flag)
    if (msg.viewOnceMessage || msg.viewOnceMessageV2 || msg.viewOnceMessageV2Extension) {
        if (m.imageMessage) return { type: 'imageMessage', inner: m.imageMessage };
        if (m.videoMessage) return { type: 'videoMessage', inner: m.videoMessage };
        if (m.audioMessage) return { type: 'audioMessage', inner: m.audioMessage };
    }

    return null;
}

module.exports = {
    category: '𝑻𝑶𝑶𝑳𝑺',

    menu: (bot, from, pushName, logo) => {
        const p = global.getPrefix();
        const menuText = box([
            '⚡ 𝑽𝑽 𝑴𝑬𝑵𝑼',
            '',
            `➫ ${p}vv`,
            '  reply to a view-once',
            '  photo/video/voice note',
            '',
            `👤 ${pushName}`
        ]);
        if (logo) bot.sendMessage(from, { image: logo.image, caption: menuText });
        else bot.sendMessage(from, { text: menuText });
    },

    list: `│ ➫ .vv`,

    vv: async (ctx) => {
        const prefix = global.getPrefix();
        const q = ctx.m.quoted;

        if (!q) {
            return ctx.bot.sendMessage(ctx.from, { text: usage(prefix) }, { quoted: ctx.m });
        }

        // Get the raw message object from the quoted message
        // Your framework puts it in q.message
        const rawMsg = q.message || q.msg?.message || {};

        // Try to find view-once media
        const found = extractViewOnceMedia(rawMsg);

        if (!found) {
            return ctx.bot.sendMessage(ctx.from, { text: notViewOnce() }, { quoted: ctx.m });
        }

        let waitMsg;
        try {
            waitMsg = await ctx.bot.sendMessage(ctx.from, {
                text: box(['⏳ 𝑼𝒏𝒍𝒐𝒄𝒌𝒊𝒏𝒈…'])
            }, { quoted: ctx.m });
        } catch (e) {}

        try {
            const buffer = await q.download();
            if (!buffer || !buffer.length) {
                throw new Error('empty download — media may have expired');
            }

            let payload;
            if (found.type === 'videoMessage') {
                payload = { video: buffer, caption: box(['🎬 𝑽𝒊𝒅𝒆𝒐 𝑼𝒏𝒍𝒐𝒄𝒌𝒆𝒅']) };
            } else if (found.type === 'audioMessage') {
                payload = { audio: buffer, mimetype: 'audio/ogg; codecs=opus', ptt: true };
            } else {
                payload = { image: buffer, caption: box(['📸 𝑷𝒉𝒐𝒕𝒐 𝑼𝒏𝒍𝒐𝒄𝒌𝒆𝒅']) };
            }

            await ctx.bot.sendMessage(ctx.from, payload, { quoted: ctx.m });

            if (waitMsg?.key) {
                try { await ctx.bot.sendMessage(ctx.from, { delete: waitMsg.key }); } catch (e) {}
            }
        } catch (e) {
            if (waitMsg?.key) {
                try { await ctx.bot.sendMessage(ctx.from, { delete: waitMsg.key }); } catch (_) {}
            }
            await ctx.bot.sendMessage(ctx.from, { text: failed(e.message) }, { quoted: ctx.m });
        }
    }
};
