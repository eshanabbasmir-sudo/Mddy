// ================================================
// VV BOT - CONFIGURATION
// ================================================

require('dotenv').config();

module.exports = {
    developer: "Mehdi",
    botName: "𝐕𝐕 𝐁𝐎𝐓",
    version: "1.0",

    // Default command prefix. Can be changed at runtime with .setprefix
    // (runtime value lives in the database so it survives restarts).
    prefix: ".",

    ownerNumber: (process.env.OWNER_NUMBER || "+923554580554").replace(/\D/g, ''),
    ownerNumbers: (process.env.OWNER_NUMBERS || "923554580554")
        .split(',')
        .map(n => n.replace(/\D/g, ''))
        .filter(Boolean),

    supportMail: process.env.SUPPORT_MAIL || "",

    // Login method: "pairing" (recommended, no QR) or "qr"
    loginMethod: (process.env.LOGIN_METHOD || "pairing").toLowerCase(),
    // Phone number used to request a pairing code (with country code, no + or spaces)
    // Can be left blank to be prompted for it in the terminal at startup.
    pairingNumber: (process.env.PAIRING_NUMBER || "").replace(/\D/g, ''),

    publicMode: true,
    autoRead: false,
    packname: "VVBot",
    author: "Mehdi",

    logoPath: {
        main: "./logo.png",
        vv: "./logo.png"
    },

    databasePath: "./database/",

    mess: {
        owner: "❌ Owner only command!",
        premium: "❌ Premium only command!",
        admin: "❌ Admin only command!",
        group: "❌ Group only command!",
        botAdmin: "❌ Bot must be admin first!",
        done: "✅ Done!",
        error: "❌ Error occurred!",
        success: "✅ Success!"
    }
};
