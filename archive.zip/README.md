# VV Bot

A minimal WhatsApp bot with a single command.

## Commands
- `.vv` — reply to a view-once photo, video, or voice note to unlock it.
- `.menu` / `.help` — shows bot info and the `.vv` usage.
- `.ping` — connection check.

## Setup
```
npm install
npm start
```
On first run you'll be asked for the WhatsApp number to link (pairing code, no QR needed), or set `PAIRING_NUMBER` in `.env`.

Developed by Mehdi.
